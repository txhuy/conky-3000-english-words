Extract the zip file to ~/.conky (create .conky folder if it not exist)
open terminal and enter: conky -c ~/.conky/theoxford3k/theoxford3000
feel free to modify it :)

HuyHaoHang @ 2012
